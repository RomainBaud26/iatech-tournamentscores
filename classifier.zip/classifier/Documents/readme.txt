Cette application est toujours sous le format expo


Je suis parti d'une application visible ici: 
https://snack.expo.io/@git/github.com/wcandillon/can-it-be-done-in-react-native:the-5-min
car j'aimais beaucoup le design 

La majeure partie du travail se trouve dans le dossier Accordion 

STEPS: 
- Ajout de plusieurs catégories (hard coded)
- Ajout de plusieurs sous catégories (hard coded)
- Mise au propre de la data
- Automatisation de la création des catégories en fonction de la data (for loops, .map)
- Transformation de l'app tsx en js pour faciliter mon travail 
- Intégration de l'envoi d'email 
- Intégration de redux (store, states, reducer, actions)
- Ajout des boutons
- Connection des actions avec les boutons 


REMAINING TO DO: 
- Open popup quand on veut ajouter des élements (pour le texte)
- Changement des for loops vers des map (pour régler le problème des ids quand on supprime certaines données)
- Intégration d'images
- Eject app 
- create docker env around
