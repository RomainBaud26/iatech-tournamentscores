class Ranking {
    constructor(id, category, rankings) {
        this.id = id;
        this.category = category;
        this.rankings = rankings;

    }

}

export default Ranking;