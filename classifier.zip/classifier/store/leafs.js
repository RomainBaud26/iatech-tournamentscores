class Leaf {
    constructor(id, category, rankings, name, points) {
        this.id = id;
        this.category = category;
        this.rankings = rankings;
        this.name = name;
        this.points = points;

    }

}

export default Leaf;