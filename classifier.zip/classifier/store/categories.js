class Category {
    constructor(id, category) {
        this.id = id;
        this.category = category;

    }

}

export default Category;